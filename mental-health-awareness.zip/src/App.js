import React from 'react';
import './App.css';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 text-gray-800 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold">Mental Health Awareness for College Students</h1>
        <p className="mt-2 text-lg">Informing and supporting students through knowledge and resources</p>
      </header>

      <section className="max-w-4xl mx-auto mb-10">
        <h2 className="text-2xl font-semibold mb-4">Why It Matters</h2>
        <p>Mental health issues among college students are on the rise. According to the American College Health Association, over 60% of students reported feeling overwhelming anxiety in the past year. Nearly 40% felt so depressed it was difficult to function. These numbers highlight the urgent need for awareness, support, and open conversation.</p>
      </section>

      <section className="max-w-4xl mx-auto mb-10">
        <h2 className="text-2xl font-semibold mb-4">Key Statistics</h2>
        <ul className="list-disc list-inside space-y-2">
          <li>1 in 5 college students has been diagnosed with a mental illness (NAMI, 2023)</li>
          <li>Only 40% of students with mental health concerns seek help (Active Minds)</li>
          <li>Suicide is the second leading cause of death among college-age individuals (CDC)</li>
        </ul>
      </section>

      <section className="max-w-4xl mx-auto mb-10">
        <h2 className="text-2xl font-semibold mb-4">Trusted Resources</h2>
        <ul className="list-disc list-inside space-y-2">
          <li><a href='https://www.nami.org' className='text-blue-600 hover:underline' target='_blank'>National Alliance on Mental Illness (NAMI)</a></li>
          <li><a href='https://www.activeminds.org' className='text-blue-600 hover:underline' target='_blank'>Active Minds</a></li>
          <li><a href='https://www.cdc.gov/mentalhealth' className='text-blue-600 hover:underline' target='_blank'>CDC Mental Health</a></li>
        </ul>
      </section>

      <footer className="text-center mt-10 text-sm text-gray-600">
        <p>&copy; 2025 Mental Health Awareness Initiative. All rights reserved.</p>
      </footer>
    </div>
  );
}
